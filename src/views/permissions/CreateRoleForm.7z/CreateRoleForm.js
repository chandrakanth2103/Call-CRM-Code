import React,{Component} from 'react';
import {Card,CardHeader,CardBody,Row,Col,Button,Label,Input,FormGroup,FormFeedback} from 'reactstrap';
import {Formik,Form} from 'formik';
import * as Yup from 'yup';
import {BootstrapTable,TableHeaderColumn} from 'react-bootstrap-table';
import 'react-bootstrap-table/dist/react-bootstrap-table-all.min.css';
//import { AppSwitch } from '@coreui/react';
import Switch from "react-switch";
import RoleData from './RoleObject';
import swal from 'sweetalert2';

const RoleArray = RoleData;

class CreateRoleForm extends Component{
    state={
        roleName:'',
        date:'',
        initialRoles:[
            {menu:'Select All', id:0},
            {menu:'DashBoard',id:1},
            {menu:'Users', id:2},
            {menu:'Permissions',id:3},
        ],
        updatedRoles:[],
        roleDetails:[],
    }

    componentDidMount(){
        console.log(this.state.roleDetails)
        var roleName=this.props.match.params.roleName;
        if(roleName != 'new'){
            //console.log(RoleArray)
            RoleArray.map(value=>{
                //console.log(value.data)
            if(roleName==value.roleName){
                 var array=[];
                 array.push(value.data);
                 //console.log(array[0])
                 //console.log(this.state.updatedRoles)
                 this.setState({
                    updatedRoles:array[0],
                    roleName:value.roleName,
                    roleDetails : RoleArray
                }
                ,()=>{console.log(this.state.updatedRoles)}
                )
                //console.log(array)
            }
        })    
        }
         else{
        var setRoles=[];
        this.state.initialRoles.map((Role,index)=>{
            setRoles.push({id:Role.id,
                [Role.menu]:{
                    canView:false,
                    canCreate:false,
                    canUpdate:false,
                    canDelete:false,
                }
            })
        })
        this.setState({
            updatedRoles:setRoles
        }
        //,()=>{console.log(this.state.updatedRoles)}
        )  
    }
    }
    handleChange=(event)=>{
        this.setState({
            [event.target.name]:event.target.value
        })
    }

    schema=()=>{
        return(
            Yup.object().shape({
                roleName:Yup.string().required('RoleName is required')
            })
        )
    }
    onSubmit=(values)=>{
        //console.log(values)
        let obj={};
        let array=[];
        //this.state.updatedRoles=RoleArray;
        if(this.props.match.params.roleName != 'new'){
            //console.log(RoleArray);
            //console.log(this.state.roleDetails)
            this.state.roleDetails.map((val)=>{
                //console.log(val.roleName,val.data)
                if(this.props.match.params.roleName==val.roleName){
                    val.roleName=values.roleName;
                }
                obj=val;
            })
            console.log(obj)
            if(this.schema){
                this.props.history.push('/roles')
                swal.fire({
                    type:'success',
                    title:'success',
                    icon:'success',
                    text:'Data updated Successfully..'
                })
            }
            }
            else{
            //this.state.updatedRoles=RoleArray;
            // console.log(this.state.roleDetails)
            // console.log(RoleArray)
            obj.roleName=values.roleName;
            obj.date=this.state.date;
            this.state.initialRoles.map((val,index)=>{
            array.push({[val.menu]: this.state.updatedRoles[index][val.menu]});
            });
            //console.log(array)
            obj.data=array
            //console.log(obj);
            this.state.roleDetails.push(obj);
            //console.log(RoleArray)
            //console.log(this.state.roleDetails)
            if(this.schema){
                this.props.history.push('/roles')
                swal.fire({
                    type:'success',
                    title:'success',
                    icon:'success',
                    text:'Your data is saved..'
                })
             }
        }     
    }

    roleChangeHandler=(row,toggle,object)=>{
        //console.log(object)
        console.log(this.state.roleDetails)
        //console.log(RoleArray)
        
        var changeRole=this.state.updatedRoles
        if(row.menu=='Select All'){
            this.state.initialRoles.map((data,index)=>{
                //console.log([data.menu])
                changeRole[index][data.menu][object]= !toggle;
            })
            this.setState({
                updatedRoles:changeRole
            }
            //,()=>{console.log(this.state.updatedRoles)}
            )
        }
        else{
            //console.log(changeRole)
            // changeRole[row.id][row.menu][object] = !this.state.updatedRoles[row.id][row.menu][object]
            // if(changeRole[row.id][row.menu][object]==false){
            //     changeRole[0]['Select All'][object]=false
            // }
            // this.setState({
            //     updatedRoles:changeRole
            // }
            //,()=>{console.log(this.state.updatedRoles)}
            //)
        }
    }

    roleFormattedData=(cell,row,object)=>{
        //console.log(this.state.updatedRoles)
        var toggle=this.state.updatedRoles[row.id] ? this.state.updatedRoles[row.id][row.menu][object] : false;
        return(<Switch
        checked={toggle}
        onChange={()=>this.roleChangeHandler(row,toggle,object)}
       />)
    }
    render(){
        return(
            <div>
                <Card>
                    <CardBody>
                        <Formik
                        enableReinitialize={true}
                        initialValues={this.state}
                        validationSchema={this.schema}
                        onSubmit={this.onSubmit}
                        >
                            {({errors,touched,handleBlur,handleSubmit,values})=>(
                                 <Form onSubmit={handleSubmit}>
                                 <Row style={{marginBottom:'10px'}}>
                                     <Col md={4}>
                                         <FormGroup>
                                             <Label htmlFor='roleName'>Role*</Label>
                                             <Input type='text' name='roleName'
                                             value={values.roleName}
                                             onChange={this.handleChange}
                                             onBlur={handleBlur}
                                             invalid={errors.roleName && touched.roleName}
                                             valid={!errors.roleName && touched.roleName} 
                                             />
                                             <FormFeedback>{errors.roleName}</FormFeedback>
                                         </FormGroup>
                                     </Col>
                                 </Row>
                                 <BootstrapTable keyField='menu'
                                 data={this.state.initialRoles}
                                 //striped
                                 hover
                                 bordered={false}
                                 >
                                     <TableHeaderColumn
                                     dataField='menu'
                                     >
                                         Menu
                                     </TableHeaderColumn>
                                     <TableHeaderColumn
                                     dataField='view'
                                     dataFormat={this.roleFormattedData}
                                     formatExtraData='canView'
                                     >
                                         View
                                     </TableHeaderColumn>
                                     <TableHeaderColumn
                                     dataField='create'
                                     dataFormat={this.roleFormattedData}
                                     formatExtraData='canCreate'
                                     >
                                         Create
                                     </TableHeaderColumn>
                                     <TableHeaderColumn
                                     dataField='update'
                                     dataFormat={this.roleFormattedData}
                                     formatExtraData='canUpdate'
                                     >
                                         Update
                                     </TableHeaderColumn>
                                     <TableHeaderColumn
                                     dataField='delete'
                                     dataFormat={this.roleFormattedData}
                                     formatExtraData='canDelete'
                                     >
                                         Delete
                                     </TableHeaderColumn>
                                 </BootstrapTable>
                                 <Row className='text-center' style={{marginTop:15}}>
                                     <Col className='text-center'>
                                         <Button style={{width:200}} size='lg' type='reset' outline color='danger'>Cancel</Button>
                                         <Button type='submit' style={{width:200,marginLeft:10}} size='lg' outline color='success'>Submit</Button>

                                     </Col>
                                 </Row>
                             </Form>

                            )}
                           
                        </Formik>
                    </CardBody>
                </Card>
                </div>
        )
    }
}
export default CreateRoleForm